/**
 * donations.js
 * ---------------------------------------------------------------
 * Domain logic for the Donation ID / lifecycle / anomaly-detection
 * system, ported from the TANAW prototype into DAONG's module
 * structure. This file does NOT talk to the DAONG backend directly
 * (that's apiService.js's job) and does NOT touch the DOM (that's
 * pages.js's job) — it only knows how to format IDs, score anomaly
 * signals, and ask the AI-explanation service a question.
 *
 * Anomaly scores here are a human-review aid, never a verdict:
 * every explanation this module produces is explicitly instructed
 * to describe a signal as "needs verification," not "confirmed
 * wrongdoing."
 * --------------------------------------------------------------- */

function money(n) {
  return '₱' + Number(n || 0).toLocaleString('en-PH');
}

function stampClass(status) {
  return status === 'flagged' ? 'flagged' : status === 'verified' ? 'verified' : 'transit';
}
function stampLabel(status) {
  return status === 'flagged' ? 'Flagged' : status === 'verified' ? 'Verified' : 'In Transit';
}

// Accepts "tn1001", "TN 1001", "1001", "TN-1001" and normalizes to "TN-1001"
function normalizeTrackingId(raw) {
  const digits = String(raw).trim().toUpperCase().replace(/^TN-?/, '').replace(/[^0-9]/g, '');
  return digits ? `TN-${digits}` : String(raw).trim().toUpperCase();
}

// Scores each anomaly signal by severity and flags which one is the
// strongest trigger, so the review panel shows a hierarchy instead of
// four equally-weighted numbers. Returns null if the donation isn't
// flagged or carries no flagReason data.
function computeAnomalySignals(donation) {
  const r = donation && donation.flagReason;
  if (!r) return null;
  const weightDropPct = ((r.expectedWeight - r.currentWeight) / r.expectedWeight) * 100;
  const signals = [
    { key: 'hours', label: 'Hours since last checkpoint', value: `${r.hoursSinceLastCheckpoint}h`, severity: r.hoursSinceLastCheckpoint / 24 },
    { key: 'weight', label: 'Weight discrepancy', value: `${r.currentWeight}kg vs ${r.expectedWeight}kg expected`, severity: weightDropPct / 10 },
    { key: 'route', label: 'Route deviation', value: `${r.routeDeviationKm} km off corridor`, severity: r.routeDeviationKm / 3 },
  ];
  const primary = signals.reduce((a, b) => (b.severity > a.severity ? b : a));
  return { signals, primaryKey: primary.key };
}

/**
 * Runs one of the backend's named AI tasks through js/ai/aiService.js —
 * the same service layer the floating assistant uses, so there is one
 * AI path in this project rather than two competing ones.
 *
 * This file sends structured DATA only. The instructions ("explain, do
 * not accuse", tone, length) live in server/ai-context.js, where a
 * visitor cannot reach them.
 *
 * Returns { ok, text }; never throws — callers just check `ok`.
 */
async function runAiTask(task, data, maxTokens) {
  if (window.daongAiService) {
    const result = await window.daongAiService.runTask({ task, data, maxTokens });
    if (result.ok) return { ok: true, text: result.text };

    // Only fall back to a browser-side model call when a developer has
    // explicitly opted in (an in-artifact/sandbox convenience). It is
    // off by default: a browser should not be calling a model vendor.
    if (window.DAONG_AI_ALLOW_DIRECT === true) return callClaudeDirect(task, data, maxTokens);

    return { ok: false, text: 'Could not reach the AI explanation service right now.' };
  }
  return { ok: false, text: 'The AI service is not available on this page.' };
}

/** Legacy direct-to-vendor path. Disabled unless DAONG_AI_ALLOW_DIRECT is set. */
async function callClaudeDirect(task, data, maxTokens) {
  try {
    const prompt = `Task: ${task}. Data: ${JSON.stringify(data)}`;
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: 'claude-sonnet-4-6', max_tokens: maxTokens, messages: [{ role: 'user', content: prompt }] }),
    });
    const payload = await response.json();
    const text = (payload.content || []).filter((b) => b.type === 'text').map((b) => b.text).join('\n').trim();
    return { ok: !!text, text: text || 'The AI service did not return a usable response.' };
  } catch (err) {
    console.error('Direct model call failed:', err);
    return { ok: false, text: 'Could not reach the AI explanation service right now.' };
  }
}

// For admins: a short, factual explanation of why a shipment was
// flagged — explicitly framed as "needs verification," never as an
// accusation of theft or wrongdoing (enforced server-side).
function explainFlag(donation) {
  const r = donation.flagReason || {};
  return runAiTask('explain-flag', {
    id: donation.id,
    category: donation.category,
    org: donation.org,
    hoursSinceLastCheckpoint: r.hoursSinceLastCheckpoint,
    expectedWeight: r.expectedWeight,
    currentWeight: r.currentWeight,
    routeDeviationKm: r.routeDeviationKm,
  }, 300);
}

// For citizens: a warm, plain-language summary of a donation's
// journey so far. Gently mentions a pending verification step
// without alarming the donor, and says nothing at all about issues
// when there aren't any.
function summarizeJourney(donation) {
  return runAiTask('summarize-journey', {
    id: donation.id,
    amount: money(donation.amountPhp),
    category: donation.category,
    org: donation.org,
    status: donation.status,
    checkpoints: (donation.checkpoints || []).map((c) => `${c.stage} at ${c.loc} (${c.time})`),
  }, 250);
}

window.donationLogic = {
  STAGES: ['Received', 'Allocated', 'Dispatched', 'In Transit', 'Delivered'],
  money,
  stampClass,
  stampLabel,
  normalizeTrackingId,
  computeAnomalySignals,
  explainFlag,
  summarizeJourney,
};
