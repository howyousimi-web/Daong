# Read me first

This archive is your complete DAONG site with the AI assistant integrated — all six
pages, both stylesheets, all JavaScript, the images, and the new backend. Nothing is
left for you to patch by hand.

Full write-up (architecture, setup, backend contract, testing checklist) is in
`AI_INTEGRATION.md`.

## Run it

```bash
cd server
npm install
cp .env.example .env      # then put your ANTHROPIC_API_KEY in .env
npm start
```

Open **http://localhost:3000**. The server serves the site and the API from one origin,
so nothing else needs configuring.

Don't open the HTML files directly from Finder — on a `file://` URL the assistant's
`/api/v1` request has nowhere to go and the browser blocks it. Always go through
localhost.

Never commit `server/.env`. `server/.gitignore` covers it.

## Merging into your repo

If you'd rather copy pieces into your existing project than use this folder wholesale:

**New — nothing of yours is overwritten:**

```
js/ai/aiContext.js  js/ai/aiService.js  js/ai/aiAssistant.js  js/ai/aiUI.js
server/            (server.js, ai-context.js, package.json, .env.example, .gitignore)
```

**Modified — diff against yours first if you've changed anything since the upload:**

```
index.html, about.html, dashboard.html, drives.html, info.html, track.html
                                    (script tags and one HTML comment only)
css/styles.css                      (one line added, inside the existing #aiat-root block)
css/ai-assistant-toggle.css         (new section 8 appended)
js/ai-assistant-toggle.js           (wired to the service layer)
js/donations.js                     (AI calls now route through the backend)
```

**Untouched originals, included so this folder runs standalone:**
`js/apiService.js`, `js/app.js`, `js/pages.js`, `images/`.

## Quick smoke test

Open the panel (bottom-right). A green dot and a greeting starting "Hi — I'm the DAONG
assistant" means it's live. Tap a suggestion chip, then ask a follow-up question and
check the answer follows on from the first. Section E of `AI_INTEGRATION.md` has the
full checklist.
