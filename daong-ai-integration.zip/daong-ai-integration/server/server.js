/**
 * server/server.js
 * -----------------------------------------------------------------
 * DAONG AI BACKEND
 *
 * The only place the model provider's API key exists. The browser never
 * sees it: the frontend posts to this server, this server adds the key
 * and the system prompt, and only the finished text comes back.
 *
 *   POST /api/v1/ai/chat      { message, history, context } -> { reply }
 *   POST /api/v1/ai/complete  { task, data, maxTokens }     -> { text }
 *   GET  /api/v1/ai/health                                  -> { ok, model }
 *
 * It also serves the static site by default, so the frontend's
 * same-origin '/api/v1' base URL works with no extra configuration.
 *
 * Run:  cd server && npm install && cp .env.example .env && npm start
 * -----------------------------------------------------------------
 */

require('dotenv').config();

const path = require('path');
const express = require('express');
const cors = require('cors');
const { buildSystemPrompt, buildTaskMessages } = require('./ai-context');

const app = express();

/* =========================================================
   CONFIG
   ========================================================= */
const PORT = Number(process.env.PORT) || 3000;
const API_KEY = process.env.ANTHROPIC_API_KEY || '';
const MODEL = process.env.ANTHROPIC_MODEL || 'claude-sonnet-5';
const ANTHROPIC_URL = 'https://api.anthropic.com/v1/messages';
const ANTHROPIC_VERSION = '2023-06-01';
const UPSTREAM_TIMEOUT_MS = Number(process.env.AI_TIMEOUT_MS) || 25000;

// Serving the site from this server keeps everything same-origin.
// Set SERVE_STATIC=false if your site is hosted separately.
const SERVE_STATIC = process.env.SERVE_STATIC !== 'false';
const STATIC_DIR = process.env.STATIC_DIR
  ? path.resolve(process.env.STATIC_DIR)
  : path.resolve(__dirname, '..');

// Only needed when the site is on a different origin from this API.
const CORS_ORIGINS = (process.env.CORS_ORIGINS || '')
  .split(',')
  .map((o) => o.trim())
  .filter(Boolean);

const MAX_MESSAGE_CHARS = 2000;
const MAX_HISTORY_TURNS = 10;
const MAX_REPLY_TOKENS = 500;

/* =========================================================
   MIDDLEWARE
   ========================================================= */
app.use(express.json({ limit: '64kb' }));

if (CORS_ORIGINS.length) {
  app.use(cors({ origin: CORS_ORIGINS, methods: ['GET', 'POST'] }));
}

// Small in-memory rate limit: enough to stop one tab from burning the
// account. Put a real limiter (or your CDN's) in front for production.
const WINDOW_MS = 60000;
const MAX_REQUESTS_PER_WINDOW = Number(process.env.RATE_LIMIT_PER_MINUTE) || 20;
const hits = new Map();

function rateLimit(req, res, next) {
  const key = req.ip || 'unknown';
  const now = Date.now();
  const entry = hits.get(key);

  if (!entry || now > entry.resetAt) {
    hits.set(key, { count: 1, resetAt: now + WINDOW_MS });
    return next();
  }
  entry.count += 1;
  if (entry.count > MAX_REQUESTS_PER_WINDOW) {
    return res.status(429).json({ error: 'rate_limited' });
  }
  return next();
}

// Keeps the map from growing without bound on a long-running process.
setInterval(() => {
  const now = Date.now();
  hits.forEach((entry, key) => {
    if (now > entry.resetAt) hits.delete(key);
  });
}, WINDOW_MS).unref();

/* =========================================================
   MODEL CALL
   One place, one timeout, one error shape. Nothing from the
   provider's error body is ever forwarded to the browser.
   ========================================================= */
async function callModel({ system, messages, maxTokens }) {
  if (!API_KEY) return { ok: false, status: 503, code: 'not_configured' };

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), UPSTREAM_TIMEOUT_MS);

  try {
    const res = await fetch(ANTHROPIC_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': API_KEY,
        'anthropic-version': ANTHROPIC_VERSION,
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: Math.min(Number(maxTokens) || 400, MAX_REPLY_TOKENS),
        system,
        messages,
      }),
      signal: controller.signal,
    });

    if (!res.ok) {
      const detail = await res.text().catch(() => '');
      console.error('[daong-ai] upstream %s: %s', res.status, detail.slice(0, 400));
      if (res.status === 429) return { ok: false, status: 429, code: 'rate_limited' };
      return { ok: false, status: 502, code: 'upstream_error' };
    }

    const data = await res.json();
    const text = (data.content || [])
      .filter((block) => block.type === 'text')
      .map((block) => block.text)
      .join('\n')
      .trim();

    if (!text) return { ok: false, status: 502, code: 'empty_response' };
    return { ok: true, text };
  } catch (err) {
    if (err && err.name === 'AbortError') {
      console.error('[daong-ai] upstream timed out after %dms', UPSTREAM_TIMEOUT_MS);
      return { ok: false, status: 504, code: 'timeout' };
    }
    console.error('[daong-ai] upstream call failed:', err && err.message);
    return { ok: false, status: 502, code: 'upstream_error' };
  } finally {
    clearTimeout(timer);
  }
}

/* =========================================================
   INPUT VALIDATION
   ========================================================= */
function normaliseHistory(raw) {
  if (!Array.isArray(raw)) return [];
  return raw
    .filter((t) => t && (t.role === 'user' || t.role === 'assistant') && typeof t.content === 'string')
    .slice(-MAX_HISTORY_TURNS)
    .map((t) => ({ role: t.role, content: t.content.slice(0, MAX_MESSAGE_CHARS) }));
}

// Anthropic requires the turn list to start with a user message and to
// alternate. A trimmed window can violate both, so repair it here.
function repairTurns(history, message) {
  const turns = history.slice();
  while (turns.length && turns[0].role !== 'user') turns.shift();

  const alternating = [];
  turns.forEach((turn) => {
    const last = alternating[alternating.length - 1];
    if (last && last.role === turn.role) alternating[alternating.length - 1] = turn;
    else alternating.push(turn);
  });

  if (alternating.length && alternating[alternating.length - 1].role === 'user') alternating.pop();
  alternating.push({ role: 'user', content: message });
  return alternating;
}

/* =========================================================
   ROUTES
   ========================================================= */
const router = express.Router();

router.get('/ai/health', (req, res) => {
  if (!API_KEY) return res.status(503).json({ ok: false, error: 'not_configured' });
  return res.json({ ok: true, model: MODEL });
});

router.post('/ai/chat', rateLimit, async (req, res) => {
  const body = req.body || {};
  const message = typeof body.message === 'string' ? body.message.trim() : '';

  if (!message) return res.status(400).json({ error: 'empty_message' });
  if (message.length > MAX_MESSAGE_CHARS) return res.status(400).json({ error: 'message_too_long' });

  const result = await callModel({
    system: buildSystemPrompt(body.context),
    messages: repairTurns(normaliseHistory(body.history), message),
    maxTokens: MAX_REPLY_TOKENS,
  });

  if (!result.ok) return res.status(result.status).json({ error: result.code });
  return res.json({ reply: result.text });
});

router.post('/ai/complete', rateLimit, async (req, res) => {
  const body = req.body || {};
  const built = buildTaskMessages(body.task, body.data);

  // Unknown task names are rejected outright: the browser picks from a
  // fixed menu of prompts, it never supplies one.
  if (!built) return res.status(400).json({ error: 'unknown_task' });

  const result = await callModel({
    system: built.system,
    messages: built.messages,
    maxTokens: Math.min(Number(body.maxTokens) || built.maxTokens, MAX_REPLY_TOKENS),
  });

  if (!result.ok) return res.status(result.status).json({ error: result.code });
  return res.json({ text: result.text });
});

app.use('/api/v1', router);

if (SERVE_STATIC) {
  app.use(express.static(STATIC_DIR));
}

// JSON (never HTML) for anything unmatched under the API prefix, so the
// frontend's error handling always has something it can parse.
app.use('/api', (req, res) => res.status(404).json({ error: 'not_found' }));

app.listen(PORT, () => {
  console.log(`DAONG AI backend listening on http://localhost:${PORT}`);
  console.log(`  model         : ${MODEL}`);
  console.log(`  API key       : ${API_KEY ? 'loaded from environment' : 'MISSING — set ANTHROPIC_API_KEY in server/.env'}`);
  console.log(`  static site   : ${SERVE_STATIC ? STATIC_DIR : 'disabled'}`);
  console.log(`  CORS origins  : ${CORS_ORIGINS.length ? CORS_ORIGINS.join(', ') : 'same-origin only'}`);
});
