/// A fundraising Drive — matches the `Drive` shape served by the DAONG
/// Node backend (`GET /api/v1/drives`). See that project's README.md
/// for the full API reference this client is built against.
class Drive {
  final String id;
  final String title;
  final String category;
  final double goalPhp;
  final double raisedPhp;
  final int percentFunded;

  const Drive({
    required this.id,
    required this.title,
    required this.category,
    required this.goalPhp,
    required this.raisedPhp,
    required this.percentFunded,
  });

  factory Drive.fromJson(Map<String, dynamic> json) => Drive(
        id: json['id'] as String,
        title: json['title'] as String,
        category: json['category'] as String,
        goalPhp: (json['goalPhp'] as num).toDouble(),
        raisedPhp: (json['raisedPhp'] as num).toDouble(),
        percentFunded: json['percentFunded'] as int,
      );
}
