import 'dart:async';
import 'dart:js_interop';
import 'dart:js_interop_unsafe';
import 'dart:ui_web' as ui_web;

import 'package:flutter/material.dart';
import 'package:web/web.dart' as web;

/// Google's published reCAPTCHA v2 TEST site key — pairs with the TEST
/// secret key already wired into the DAONG backend's server/recaptcha.js,
/// so pledges verify successfully with zero setup. Swap for a real site
/// key from https://www.google.com/recaptcha/admin before this goes
/// anywhere real; the test key accepts everyone, bots included.
const String kRecaptchaTestSiteKey = '6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI';

@JS('grecaptcha.render')
external JSNumber _grecaptchaRender(String container, JSAny options);

@JS('grecaptcha.reset')
external void _grecaptchaReset(JSNumber widgetId);

/// A visible "I'm not a robot" checkbox, embedded via an HTML platform
/// view (Flutter web can't render third-party JS widgets directly).
/// Gates the pledge form the same way it gates the HTML site's pledge
/// form — both point at the same backend route and the same check.
class RecaptchaWidget extends StatefulWidget {
  final String siteKey;
  final ValueChanged<String?> onVerified;

  const RecaptchaWidget({
    super.key,
    this.siteKey = kRecaptchaTestSiteKey,
    required this.onVerified,
  });

  @override
  State<RecaptchaWidget> createState() => RecaptchaWidgetState();
}

class RecaptchaWidgetState extends State<RecaptchaWidget> {
  static int _instanceCounter = 0;
  late final String _viewType;
  late final String _elementId;
  JSNumber? _widgetId;
  Timer? _pollTimer;
  bool _rendered = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    final id = _instanceCounter++;
    _viewType = 'recaptcha-view-$id';
    _elementId = 'recaptcha-div-$id';

    ui_web.platformViewRegistry.registerViewFactory(_viewType, (int _) {
      final div = web.HTMLDivElement()..id = _elementId;
      return div;
    });

    _waitForApiThenRender();
  }

  void _waitForApiThenRender() {
    _pollTimer = Timer.periodic(const Duration(milliseconds: 200), (timer) {
      final hasApi = web.window.hasProperty('grecaptcha'.toJS).toDart;
      if (!hasApi) return;
      timer.cancel();
      WidgetsBinding.instance.addPostFrameCallback((_) => _render());
    });
  }

  void _render() {
    try {
      final options = JSObject()
        ..setProperty('sitekey'.toJS, widget.siteKey.toJS)
        ..setProperty(
          'callback'.toJS,
          ((JSString token) => widget.onVerified(token.toDart)).toJS,
        )
        ..setProperty(
          'expired-callback'.toJS,
          (() => widget.onVerified(null)).toJS,
        );
      _widgetId = _grecaptchaRender(_elementId, options);
      setState(() => _rendered = true);
    } catch (e) {
      setState(() => _error = 'Could not load reCAPTCHA: $e');
    }
  }

  void reset() {
    final id = _widgetId;
    if (id != null) {
      _grecaptchaReset(id);
      widget.onVerified(null);
    }
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_error != null) {
      return Text(_error!, style: const TextStyle(color: Colors.red));
    }
    return SizedBox(
      width: 304,
      height: 78,
      child: Stack(
        children: [
          HtmlElementView(viewType: _viewType),
          if (!_rendered)
            const Positioned.fill(
              child: Center(child: CircularProgressIndicator(strokeWidth: 2)),
            ),
        ],
      ),
    );
  }
}
