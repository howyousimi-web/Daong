import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/drive.dart';
import '../providers/app_state.dart';
import '../utils/theme.dart';
import '../widgets/recaptcha_widget.dart';

class DrivesScreen extends StatefulWidget {
  const DrivesScreen({super.key});

  @override
  State<DrivesScreen> createState() => _DrivesScreenState();
}

class _DrivesScreenState extends State<DrivesScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<AppState>().load();
    });
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final colors = context.colors;

    if (app.state == LoadState.loading || app.state == LoadState.idle) {
      return const Center(child: CircularProgressIndicator());
    }
    if (app.state == LoadState.error) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text(
            'Could not reach the DAONG backend at localhost:3000.\n${app.error}',
            textAlign: TextAlign.center,
          ),
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: app.load,
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(20),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 1000),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Donation Drives',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              Text(
                'Pledge to a drive and get your own tracked donation ID.',
                style: TextStyle(color: colors.textSecondary),
              ),
              const SizedBox(height: 20),
              // A Wrap of fixed-width, self-sizing cards instead of a
              // GridView with a fixed aspect ratio: card height then
              // follows its actual content (title length, etc.) instead
              // of a guessed ratio that overflows whenever a title wraps
              // to 2 lines.
              LayoutBuilder(builder: (context, constraints) {
                final columns = constraints.maxWidth > 800 ? 2 : 1;
                final spacing = 16.0;
                final cardWidth = (constraints.maxWidth - spacing * (columns - 1)) / columns;
                return Wrap(
                  spacing: spacing,
                  runSpacing: spacing,
                  children: [
                    for (final drive in app.drives)
                      SizedBox(width: cardWidth, child: _DriveCard(drive: drive)),
                  ],
                );
              }),
            ],
          ),
        ),
      ),
    );
  }
}

class _DriveCard extends StatelessWidget {
  final Drive drive;
  const _DriveCard({required this.drive});

  @override
  Widget build(BuildContext context) {
    final colors = context.colors;
    final app = context.watch<AppState>();
    final linked = app.donationsFor(drive.id);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(drive.category.toUpperCase(),
                style: TextStyle(
                    fontSize: 11, fontWeight: FontWeight.w700, color: colors.textSecondary, letterSpacing: 0.6)),
            const SizedBox(height: 6),
            Text(drive.title,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
            const SizedBox(height: 14),
            ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: LinearProgressIndicator(
                value: drive.percentFunded / 100,
                minHeight: 8,
                backgroundColor: colors.border,
                color: colors.primary,
              ),
            ),
            const SizedBox(height: 6),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('${drive.percentFunded}% funded',
                    style: const TextStyle(fontWeight: FontWeight.w700)),
                Text('${linked.length} tracked donation${linked.length == 1 ? '' : 's'}',
                    style: TextStyle(fontSize: 12, color: colors.textSecondary)),
              ],
            ),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () => _openPledgeDialog(context, drive.id, drive.title),
                child: const Text('Pledge to this Drive'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _openPledgeDialog(BuildContext context, String driveId, String title) {
    showDialog(
      context: context,
      builder: (_) => _PledgeDialog(driveId: driveId, driveTitle: title),
    );
  }
}

class _PledgeDialog extends StatefulWidget {
  final String driveId;
  final String driveTitle;
  const _PledgeDialog({required this.driveId, required this.driveTitle});

  @override
  State<_PledgeDialog> createState() => _PledgeDialogState();
}

class _PledgeDialogState extends State<_PledgeDialog> {
  final _amountController = TextEditingController();
  final _donorController = TextEditingController();
  final _captchaKey = GlobalKey<RecaptchaWidgetState>();
  String? _captchaToken;
  bool _submitting = false;
  String? _error;
  String? _successId;

  @override
  Widget build(BuildContext context) {
    final app = context.read<AppState>();

    if (!app.isLoggedIn) {
      return AlertDialog(
        title: const Text('Log in required'),
        content: const Text('Log in from the app bar to pledge to a drive.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK')),
        ],
      );
    }

    if (_successId != null) {
      return AlertDialog(
        title: const Text('Pledge received'),
        content: Text('Tracked as $_successId.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Done')),
        ],
      );
    }

    return AlertDialog(
      title: Text('Pledge to ${widget.driveTitle}'),
      content: SizedBox(
        width: 340,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: _donorController,
              decoration: const InputDecoration(labelText: 'Your name (optional)'),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _amountController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Amount (PHP)'),
            ),
            const SizedBox(height: 14),
            RecaptchaWidget(
              key: _captchaKey,
              onVerified: (token) => setState(() => _captchaToken = token),
            ),
            if (_error != null) ...[
              const SizedBox(height: 8),
              Text(_error!, style: const TextStyle(color: Colors.red, fontSize: 12)),
            ],
          ],
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        FilledButton(
          onPressed: _submitting || _captchaToken == null ? null : _submit,
          child: Text(_submitting ? 'Submitting…' : 'Confirm Pledge'),
        ),
      ],
    );
  }

  Future<void> _submit() async {
    final amount = double.tryParse(_amountController.text);
    if (amount == null || amount <= 0) {
      setState(() => _error = 'Enter a valid amount.');
      return;
    }
    setState(() {
      _submitting = true;
      _error = null;
    });
    try {
      final donation = await context.read<AppState>().pledge(
            driveId: widget.driveId,
            amountPhp: amount,
            donor: _donorController.text.trim().isEmpty ? 'Anonymous Donor' : _donorController.text.trim(),
            recaptchaToken: _captchaToken!,
            org: widget.driveTitle,
          );
      setState(() => _successId = donation.id);
    } catch (e) {
      setState(() {
        _error = 'Could not submit that pledge. Please try again.';
        _submitting = false;
      });
      _captchaKey.currentState?.reset();
      setState(() => _captchaToken = null);
    }
  }

  @override
  void dispose() {
    _amountController.dispose();
    _donorController.dispose();
    super.dispose();
  }
}
