import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'providers/app_state.dart';
import 'providers/theme_provider.dart';
import 'screens/drives_screen.dart';
import 'screens/track_screen.dart';
import 'services/daong_api.dart';
import 'utils/theme.dart';

/// Base URL of the DAONG Node backend this Flutter client talks to.
/// Defaults to the local dev server — see that project's README.md
/// for its full /api/v1 route reference. Point this at a deployed
/// backend when you have one; CORS is wide open there for exactly
/// this kind of cross-origin client.
const String kDaongApiBaseUrl = 'http://localhost:3000/api/v1';

void main() {
  final api = DaongApi(baseUrl: kDaongApiBaseUrl);
  runApp(DaongFlutterApp(api: api));
}

class DaongFlutterApp extends StatelessWidget {
  final DaongApi api;
  const DaongFlutterApp({super.key, required this.api});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AppState(api)),
        ChangeNotifierProvider(create: (_) => ThemeProvider()),
      ],
      child: Consumer<ThemeProvider>(
        builder: (context, themeProvider, _) => MaterialApp(
          title: 'DAONG',
          debugShowCheckedModeBanner: false,
          theme: buildLightTheme(),
          darkTheme: buildDarkTheme(),
          themeMode: themeProvider.mode,
          home: const HomeShell(),
        ),
      ),
    );
  }
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _tab = 0;

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final themeProvider = context.watch<ThemeProvider>();

    return Scaffold(
      appBar: AppBar(
        titleSpacing: 12,
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.shield_moon, color: context.colors.primary),
            const SizedBox(width: 10),
            const Flexible(
              child: Text('DAONG',
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontWeight: FontWeight.w800)),
            ),
          ],
        ),
        actions: [
          if (app.isLoggedIn)
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: Center(
                child: Chip(
                  label: Text(app.userRole == 'admin' ? 'Coordinator' : 'Donor'),
                  onDeleted: app.logout,
                  deleteIcon: const Icon(Icons.logout, size: 16),
                ),
              ),
            )
          else
            TextButton(
              onPressed: () => app.login('donor'),
              child: const Text('Log In (Demo)'),
            ),
          IconButton(
            tooltip: themeProvider.isDark ? 'Switch to light mode' : 'Switch to dark mode',
            icon: Icon(themeProvider.isDark ? Icons.light_mode : Icons.dark_mode),
            onPressed: themeProvider.toggle,
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: IndexedStack(
        index: _tab,
        children: const [DrivesScreen(), TrackScreen()],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.volunteer_activism), label: 'Drives'),
          NavigationDestination(icon: Icon(Icons.search), label: 'Track'),
        ],
      ),
    );
  }
}
