import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/donation.dart';
import '../providers/app_state.dart';
import '../utils/theme.dart';
import '../widgets/checkpoint_map.dart';

class TrackScreen extends StatefulWidget {
  const TrackScreen({super.key});

  @override
  State<TrackScreen> createState() => _TrackScreenState();
}

class _TrackScreenState extends State<TrackScreen> {
  final _controller = TextEditingController(text: 'TN-1001');
  Donation? _result;
  String? _notFoundId;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final app = context.read<AppState>();
      if (app.state == LoadState.idle) await app.load();
      _search();
    });
  }

  void _search() {
    final app = context.read<AppState>();
    final normalized = _normalize(_controller.text);
    final match = app.donations.where((d) => d.id.toUpperCase() == normalized).toList();
    setState(() {
      if (match.isEmpty) {
        _result = null;
        _notFoundId = _controller.text;
      } else {
        _result = match.first;
        _notFoundId = null;
      }
    });
  }

  String _normalize(String raw) {
    final digits = raw.trim().toUpperCase().replaceFirst(RegExp(r'^TN-?'), '').replaceAll(RegExp(r'[^0-9]'), '');
    return digits.isEmpty ? raw.trim().toUpperCase() : 'TN-$digits';
  }

  @override
  Widget build(BuildContext context) {
    final colors = context.colors;
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 640),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Track a Donation',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              Text('Public lookup — no login required.',
                  style: TextStyle(color: colors.textSecondary)),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _controller,
                      decoration: const InputDecoration(
                        labelText: 'Tracking ID',
                        hintText: 'e.g. TN-1001',
                      ),
                      onSubmitted: (_) => _search(),
                    ),
                  ),
                  const SizedBox(width: 10),
                  ElevatedButton(onPressed: _search, child: const Text('Search')),
                ],
              ),
              const SizedBox(height: 20),
              if (_notFoundId != null)
                Text('No donation found for "$_notFoundId". Try TN-1001, TN-1002, or TN-1003.',
                    style: TextStyle(color: colors.textSecondary)),
              if (_result != null) _DonationDetail(donation: _result!),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }
}

class _DonationDetail extends StatelessWidget {
  final Donation donation;
  const _DonationDetail({required this.donation});

  Color _statusColor(BuildContext context) {
    final colors = context.colors;
    switch (donation.status) {
      case 'flagged':
        return colors.danger;
      case 'verified':
        return colors.success;
      default:
        return colors.primary;
    }
  }

  @override
  Widget build(BuildContext context) {
    final colors = context.colors;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(donation.id, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                Chip(
                  label: Text(donation.status.toUpperCase()),
                  backgroundColor: _statusColor(context).withValues(alpha: 0.15),
                  labelStyle: TextStyle(color: _statusColor(context), fontWeight: FontWeight.w700, fontSize: 11),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text('₱${donation.amountPhp.toStringAsFixed(0)} — ${donation.category}',
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
            Text('${donation.org} · Logged ${donation.date}',
                style: TextStyle(color: colors.textSecondary, fontSize: 12)),
            const SizedBox(height: 16),
            for (var i = 0; i < Donation.stages.length; i++) _TimelineRow(donation: donation, stageIndex: i),
            if (donation.geoCheckpoints.isNotEmpty) ...[
              const SizedBox(height: 16),
              CheckpointMap(checkpoints: donation.checkpoints),
            ],
          ],
        ),
      ),
    );
  }
}

class _TimelineRow extends StatelessWidget {
  final Donation donation;
  final int stageIndex;
  const _TimelineRow({required this.donation, required this.stageIndex});

  @override
  Widget build(BuildContext context) {
    final colors = context.colors;
    final stage = Donation.stages[stageIndex];
    final cp = donation.checkpoints.where((c) => c.stage == stage).toList();
    final reached = cp.isNotEmpty;
    final isFlagged = donation.status == 'flagged' && stageIndex == donation.stageIndex;
    final color = isFlagged ? colors.danger : (reached ? colors.success : colors.border);

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 26,
            height: 26,
            alignment: Alignment.center,
            decoration: BoxDecoration(color: color, shape: BoxShape.circle),
            child: Text(
              reached ? (isFlagged ? '!' : '✓') : '${stageIndex + 1}',
              style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w700),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(stage, style: const TextStyle(fontWeight: FontWeight.w700)),
                if (reached)
                  Text('${cp.first.loc} · ${cp.first.time}',
                      style: TextStyle(fontSize: 12, color: colors.textSecondary))
                else
                  Text('Not yet reached', style: TextStyle(fontSize: 12, color: colors.textSecondary)),
                if (isFlagged)
                  Text('Flagged for verification — under review.',
                      style: TextStyle(fontSize: 12, color: colors.danger)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
