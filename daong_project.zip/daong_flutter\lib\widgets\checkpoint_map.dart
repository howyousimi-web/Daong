import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

import '../models/donation.dart';
import '../utils/theme.dart';

/// Plots a donation's geo-tagged checkpoints on a route map — the
/// Flutter equivalent of the HTML site's Google Maps route on
/// track.html. Uses OpenStreetMap tiles via `flutter_map` instead of
/// the Google Maps JS API the web page uses, since there's no Flutter
/// web equivalent of that script-tag approach that stays zero-config;
/// this renders real map tiles immediately with no API key, same
/// tradeoff made for the ReliefLedger Flutter app's map screens.
class CheckpointMap extends StatelessWidget {
  final List<Checkpoint> checkpoints;

  const CheckpointMap({super.key, required this.checkpoints});

  @override
  Widget build(BuildContext context) {
    final geo = checkpoints.where((c) => c.hasCoordinates).toList();
    if (geo.isEmpty) return const SizedBox.shrink();

    final points = geo.map((c) => LatLng(c.lat!, c.lng!)).toList();
    final colors = context.colors;

    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: SizedBox(
        height: 260,
        child: FlutterMap(
          options: MapOptions(
            initialCenter: points.last,
            initialZoom: 12,
          ),
          children: [
            TileLayer(
              urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
              userAgentPackageName: 'com.example.daong_flutter',
            ),
            PolylineLayer(polylines: [
              Polyline(points: points, color: colors.primary, strokeWidth: 3),
            ]),
            MarkerLayer(
              markers: [
                for (var i = 0; i < geo.length; i++)
                  Marker(
                    point: points[i],
                    width: 32,
                    height: 32,
                    child: Tooltip(
                      message: '${geo[i].stage} — ${geo[i].loc}',
                      child: Icon(Icons.location_on, color: colors.primary, size: 32),
                    ),
                  ),
              ],
            ),
            const RichAttributionWidget(
              attributions: [TextSourceAttribution('© OpenStreetMap contributors')],
            ),
          ],
        ),
      ),
    );
  }
}
