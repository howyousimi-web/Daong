import 'package:flutter/foundation.dart';

import '../models/donation.dart';
import '../models/drive.dart';
import '../services/daong_api.dart';

enum LoadState { idle, loading, loaded, error }

/// Single shared state for the app: drives, donations, and auth —
/// small enough that one provider covers it rather than splitting
/// into several the way the larger ReliefLedger Flutter app did.
class AppState extends ChangeNotifier {
  AppState(this._api);

  final DaongApi _api;

  List<Drive> _drives = [];
  List<Donation> _donations = [];
  LoadState _state = LoadState.idle;
  String? _error;
  String? _userRole; // null = not logged in

  List<Drive> get drives => _drives;
  List<Donation> get donations => _donations;
  LoadState get state => _state;
  String? get error => _error;
  String? get userRole => _userRole;
  bool get isLoggedIn => _userRole != null;

  List<Donation> donationsFor(String driveId) =>
      _donations.where((d) => d.driveId == driveId).toList();

  Future<void> load() async {
    _state = LoadState.loading;
    notifyListeners();
    try {
      final results = await Future.wait([_api.getDrives(), _api.getDonations()]);
      _drives = results[0] as List<Drive>;
      _donations = results[1] as List<Donation>;
      _state = LoadState.loaded;
    } catch (e) {
      _error = e.toString();
      _state = LoadState.error;
    }
    notifyListeners();
  }

  Future<void> login(String role) async {
    await _api.login(role);
    _userRole = role;
    notifyListeners();
  }

  void logout() {
    _api.logout();
    _userRole = null;
    notifyListeners();
  }

  Future<Donation> pledge({
    required String driveId,
    required double amountPhp,
    required String donor,
    required String recaptchaToken,
    String? org,
  }) async {
    final donation = await _api.pledge(
      driveId: driveId,
      amountPhp: amountPhp,
      donor: donor,
      recaptchaToken: recaptchaToken,
      org: org,
    );
    await load(); // refresh drive totals + donation list
    return donation;
  }

  Future<void> logCheckpoint(String donationId) async {
    await _api.logCheckpoint(donationId);
    await load();
  }
}
