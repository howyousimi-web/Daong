/// One checkpoint in a Donation's delivery trail. `lat`/`lng` are
/// optional — only present on checkpoints the backend has geo-tagged —
/// and are what powers the route map on the Track screen.
///
/// `previousHash`/`hash` are the tamper-evident SHA-256 chain the
/// backend stamps on every checkpoint (see the DAONG backend's
/// store.js). This client doesn't verify them itself, but keeps them
/// around since `GET /donations/:id/verify` is what confirms the
/// chain server-side.
class Checkpoint {
  final String stage;
  final String loc;
  final String time;
  final double? lat;
  final double? lng;

  const Checkpoint({
    required this.stage,
    required this.loc,
    required this.time,
    this.lat,
    this.lng,
  });

  bool get hasCoordinates => lat != null && lng != null;

  factory Checkpoint.fromJson(Map<String, dynamic> json) => Checkpoint(
        stage: json['stage'] as String,
        loc: json['loc'] as String,
        time: json['time'] as String,
        lat: (json['lat'] as num?)?.toDouble(),
        lng: (json['lng'] as num?)?.toDouble(),
      );
}

/// A tracked donation — matches the `Donation` shape served by the
/// DAONG Node backend (`GET /api/v1/donations`).
class Donation {
  static const stages = ['Received', 'Allocated', 'Dispatched', 'In Transit', 'Delivered'];

  final String id;
  final String? driveId;
  final String donor;
  final double amountPhp;
  final String category;
  final String org;
  final String date;
  final int stageIndex;
  final String status; // transit | verified | flagged
  final List<Checkpoint> checkpoints;

  const Donation({
    required this.id,
    required this.driveId,
    required this.donor,
    required this.amountPhp,
    required this.category,
    required this.org,
    required this.date,
    required this.stageIndex,
    required this.status,
    required this.checkpoints,
  });

  List<Checkpoint> get geoCheckpoints => checkpoints.where((c) => c.hasCoordinates).toList();

  factory Donation.fromJson(Map<String, dynamic> json) => Donation(
        id: json['id'] as String,
        driveId: json['driveId'] as String?,
        donor: json['donor'] as String,
        amountPhp: (json['amountPhp'] as num).toDouble(),
        category: json['category'] as String,
        org: json['org'] as String,
        date: json['date'] as String,
        stageIndex: json['stageIndex'] as int,
        status: json['status'] as String,
        checkpoints: (json['checkpoints'] as List<dynamic>)
            .map((c) => Checkpoint.fromJson(c as Map<String, dynamic>))
            .toList(),
      );
}
