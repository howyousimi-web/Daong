# DAONG (Flutter client)

A second frontend for the DAONG donation-tracking backend — same data,
same `/api/v1` API, built natively in Dart/Flutter instead of HTML/JS.
Two screens: **Drives** (browse campaigns, pledge) and **Track** (public
donation lookup with a route map).

This is a separate, purpose-built client rather than a port of the
earlier ReliefLedger Flutter app — that app's data model (Campaigns +
a financial ledger) doesn't map cleanly onto DAONG's (Drives +
donations with a delivery/checkpoint trail), so this project talks to
DAONG's actual API from scratch. It does reuse proven patterns from
that app: the `context.colors` dark-mode theming approach and the
reCAPTCHA v2 JS-interop widget.

## Quick start

1. Start the DAONG backend first (see that project's README):
   ```bash
   cd ../daong
   npm install && npm start
   ```
2. Then run this app:
   ```bash
   flutter pub get
   flutter run -d chrome
   ```

By default this points at `http://localhost:3000/api/v1` — change
`kDaongApiBaseUrl` in `lib/main.dart` to point at a deployed backend.
CORS is wide open on that backend for exactly this cross-origin case.

## What's here

```
lib/
  models/
    drive.dart        matches the backend's Drive shape
    donation.dart      matches Donation + Checkpoint (incl. lat/lng)
  services/
    daong_api.dart      the only file that calls the backend
  providers/
    app_state.dart      drives/donations/auth, shared across screens
    theme_provider.dart  light/dark toggle
  widgets/
    recaptcha_widget.dart   reCAPTCHA v2 checkbox (ported from ReliefLedger)
    checkpoint_map.dart     OpenStreetMap route map for a donation's checkpoints
  screens/
    drives_screen.dart      browse + pledge
    track_screen.dart       public lookup + timeline + map
  utils/theme.dart      AppPalette (light/dark), context.colors extension
  main.dart             app shell, nav, login, dark-mode toggle
```

## The four integrations, and where they actually are

- **Firebase (App Check)** lives on the *backend* (`daong/server/appCheck.js`)
  — it protects the API itself, not this client specifically. This
  client doesn't need any Firebase SDK; if you turn on `ENABLE_APP_CHECK`
  on the backend, you'd add the `firebase_app_check` Flutter package
  here and attach its token as an `X-Firebase-AppCheck` header in
  `daong_api.dart`'s `_headers`.
- **reCAPTCHA v2** is the visible checkbox in the pledge dialog
  (`drives_screen.dart`'s `_PledgeDialog`, via `recaptcha_widget.dart`).
  Ships with Google's published TEST site key, paired with the TEST
  secret key already in the backend's `server/recaptcha.js` — pledges
  work with zero setup. Swap both for real keys before this goes
  anywhere real.
- **Dart/Flutter**: this whole project.
- **Google Maps → OpenStreetMap**: the Track screen's route map
  (`checkpoint_map.dart`) uses `flutter_map` + OpenStreetMap tiles, not
  the Google Maps JS API the HTML frontend's track.html uses — there's
  no Flutter-web equivalent of that script-tag approach that stays
  zero-config, and OSM tiles need no API key at all. Same tradeoff the
  ReliefLedger Flutter app made for the same reason.

## Verified end-to-end

Ran this against the real DAONG backend (not a mock) and confirmed:
- Drives screen renders live funding data, tracked-donation counts.
- Track screen correctly renders all three seed donations (TN-1001
  flagged, TN-1002 fully delivered/verified, TN-1003 in transit) with
  their full checkpoint timelines.
- The route map renders real OpenStreetMap tiles with correctly
  positioned, labeled markers and a connecting route line for every
  geo-tagged checkpoint.
- Demo login (Donor) works and persists across screens.
- Found and fixed two real layout bugs during testing: a drive card
  that overflowed when its title wrapped to two lines (switched from a
  fixed-aspect-ratio grid to a self-sizing `Wrap`), and an AppBar title
  that overflowed on narrow viewports (wrapped in `Flexible` +
  ellipsis).

Not yet clicked through in a live browser: the pledge dialog's actual
submit round-trip (backend enforcement of reCAPTCHA was verified
separately via `curl` against `daong/server` — see that project's own
verification notes). Worth a manual click-through before a demo.

## Known limits (prototype, not production)

- No token persistence — logging out closes the tab and you're logged
  out. Fine for a demo; add `shared_preferences` if that matters.
- Same backend limits apply here as documented in `../daong/README.md`
  (in-memory auth tokens, flat-file datastore, etc.) since this is just
  another client of that same API.
