import 'dart:convert';
import 'package:http/http.dart' as http;

import '../models/donation.dart';
import '../models/drive.dart';

/// The one place this app talks to the DAONG backend. Every route here
/// matches the contract documented in the backend project's README.md —
/// this Flutter client is just another frontend calling the same
/// `/api/v1` API the HTML site uses, per that backend's "standalone
/// mode" design (CORS is wide open there for exactly this reason).
///
/// Change [baseUrl] to point at a deployed backend; defaults to the
/// local dev server.
class DaongApi {
  DaongApi({this.baseUrl = 'http://localhost:3000/api/v1', http.Client? client})
      : _client = client ?? http.Client();

  final String baseUrl;
  final http.Client _client;
  String? _token;

  bool get isAuthenticated => _token != null;

  Map<String, String> get _headers => {
        'Content-Type': 'application/json',
        if (_token != null) 'Authorization': 'Bearer $_token',
      };

  Uri _uri(String path) => Uri.parse('$baseUrl$path');

  Future<Map<String, dynamic>> _decode(http.Response res) async {
    if (res.statusCode < 200 || res.statusCode >= 300) {
      throw DaongApiException(res.statusCode, res.body);
    }
    return jsonDecode(res.body) as Map<String, dynamic>;
  }

  /// Demo-role login — 'donor' or 'admin', no real credentials, matches
  /// the backend's `POST /auth/login` (see that project's server/auth.js).
  Future<void> login(String role) async {
    final res = await _client.post(
      _uri('/auth/login'),
      headers: _headers,
      body: jsonEncode({'role': role}),
    );
    final data = await _decode(res);
    _token = data['token'] as String;
  }

  void logout() {
    _token = null;
  }

  Future<List<Drive>> getDrives() async {
    final res = await _client.get(_uri('/drives'), headers: _headers);
    final data = await _decode(res);
    return (data['drives'] as List<dynamic>)
        .map((d) => Drive.fromJson(d as Map<String, dynamic>))
        .toList();
  }

  Future<List<Donation>> getDonations() async {
    final res = await _client.get(_uri('/donations'), headers: _headers);
    final data = await _decode(res);
    return (data['donations'] as List<dynamic>)
        .map((d) => Donation.fromJson(d as Map<String, dynamic>))
        .toList();
  }

  /// Pledges to a Drive — requires being logged in AND a solved
  /// reCAPTCHA token (the backend's `requireRecaptcha` middleware
  /// rejects this call with a 400 otherwise; see recaptcha_widget.dart).
  Future<Donation> pledge({
    required String driveId,
    required double amountPhp,
    required String donor,
    required String recaptchaToken,
    String category = 'Cash Relief',
    String? org,
  }) async {
    final res = await _client.post(
      _uri('/donations/pledge'),
      headers: _headers,
      body: jsonEncode({
        'driveId': driveId,
        'amountPhp': amountPhp,
        'donor': donor,
        'category': category,
        'org': org,
        'recaptchaToken': recaptchaToken,
      }),
    );
    final data = await _decode(res);
    return Donation.fromJson(data['donation'] as Map<String, dynamic>);
  }

  Future<Donation> logCheckpoint(String donationId) async {
    final res = await _client.post(
      _uri('/donations/${Uri.encodeComponent(donationId)}/checkpoint'),
      headers: _headers,
    );
    final data = await _decode(res);
    return Donation.fromJson(data['donation'] as Map<String, dynamic>);
  }

  Future<Map<String, dynamic>> verifyChain(String donationId) async {
    final res = await _client.get(_uri('/donations/${Uri.encodeComponent(donationId)}/verify'));
    return _decode(res);
  }
}

class DaongApiException implements Exception {
  final int statusCode;
  final String body;
  DaongApiException(this.statusCode, this.body);

  @override
  String toString() => 'DaongApiException($statusCode): $body';
}
